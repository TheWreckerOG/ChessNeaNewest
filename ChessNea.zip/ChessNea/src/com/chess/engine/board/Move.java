package com.chess.engine.board;

import com.chess.engine.piece.Piece;

public abstract class Move {

    final Board board;
    final Piece MovedPiece;
    final int destinedCoordinate;

    private Move(final Board board, final Piece MovedPiece, final int destinedCoordinate){

        this.board = board;
        this.MovedPiece = MovedPiece;
        this.destinedCoordinate = destinedCoordinate;
    }

    public static final class MajorMove extends Move{

        public MajorMove(final Board board, final Piece MovedPiece, final int destinedCoordinate) {
            super(board, MovedPiece, destinedCoordinate);
        }
    }

    public static final class Attack extends Move{

        final Piece AttackedPiece;

        public Attack(final Board board, final Piece MovedPiece, final int destinedCoordinate, final Piece AttackedPiece) {
            super(board, MovedPiece, destinedCoordinate);
            this.AttackedPiece = AttackedPiece;
        }

    }
}