package com.chess.engine.board;

public class BoardUtils {

    public static final boolean[] First_Column = intColumn(0);
    public static final boolean[] Second_Column = intColumn(1);
    public static final boolean[] Seventh_Column = intColumn(6);
    public static final boolean[] Eighth_Column = intColumn(7);

    public static final boolean[] Second_Row = intRow(8);
    public static final boolean[] Seventh_Row = intRow(48);

    public static final int Num_Tiles = 64;
    public static final int Num_Tiles_Row = 8;

    private static boolean[] intColumn(int ColumnNumber) {

        final boolean[] column = new boolean[Num_Tiles];

        do{
            column[ColumnNumber] = true;
            ColumnNumber += Num_Tiles_Row;
        }

        while(ColumnNumber < Num_Tiles);
        return column;
    }

    private BoardUtils(){

        throw new RuntimeException("Cant Do that");
    }

    private static boolean[] intRow(int rowNumber){

        final boolean[] row = new boolean[Num_Tiles];

        do{

            row[rowNumber] = true;
            rowNumber++;
        }
        while(rowNumber % Num_Tiles_Row != 0);

        return row;
    }

    public static boolean isValidTile(final int coordinate) {
        return coordinate >= 0 && coordinate < Num_Tiles;
    }
}
