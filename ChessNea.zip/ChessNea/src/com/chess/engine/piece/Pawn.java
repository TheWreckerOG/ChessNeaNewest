package com.chess.engine.piece;

import com.chess.engine.Team;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static com.chess.engine.board.Move.*;

public class Pawn extends Piece{

    private final static int[] Possible_Move_Coordinates = {7,8,9,16};



    public Pawn(final Team pieceTeam, final int piecePosition) {
        super(piecePosition, pieceTeam, PieceType.PAWN);
    }

    @Override
    public Collection<Move> calcLegalMoves(final Board board) {

        final List<Move> LegalMoves = new ArrayList<>();

        for(final int currentCandidateOffset : Possible_Move_Coordinates){

            final int candidateDestinationCoordinate = this.piecePosition + (this.getPieceTeam().getDirection() * currentCandidateOffset);

            if(!BoardUtils.isValidTile(candidateDestinationCoordinate)){

                continue;
            }

            if(currentCandidateOffset ==8 && board.getTile(candidateDestinationCoordinate).isTileOccupied()){

                LegalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
            }

            else if(currentCandidateOffset == 16 && this.isFirstMove() &&
                    (BoardUtils.Second_Row[this.piecePosition] && this.getPieceTeam().isBlack()) ||
                    (BoardUtils.Seventh_Row[this.piecePosition] && this.getPieceTeam().isWhite())){

                final int behindCandidateCoordinate = this.piecePosition + (this.getPieceTeam().getDirection() * 8);

                if(board.getTile(behindCandidateCoordinate).isTileOccupied() && board.getTile(candidateDestinationCoordinate).isTileOccupied()){

                    LegalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
                }
            }

            else if(currentCandidateOffset == 7 &&
                    !((BoardUtils.Eighth_Column[this.piecePosition] && this.pieceTeam.isWhite() ||
                            (BoardUtils.First_Column[this.piecePosition] && this.pieceTeam.isBlack())))){

                if(board.getTile(candidateDestinationCoordinate).isTileOccupied()){

                    final Piece pieceOnCandidate = board.getTile(candidateDestinationCoordinate).getPiece();
                    if(this.pieceTeam != pieceOnCandidate.getPieceTeam()){
                        LegalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
                    }
                }
            }

            else if(currentCandidateOffset == 9 &&
                    !((BoardUtils.First_Column[this.piecePosition] && this.pieceTeam.isWhite() ||
                            (BoardUtils.Eighth_Column[this.piecePosition] && this.pieceTeam.isBlack())))){

                final Piece pieceOnCandidate = board.getTile(candidateDestinationCoordinate).getPiece();
                if(pieceOnCandidate != null && this.pieceTeam != pieceOnCandidate.getPieceTeam()){

                    LegalMoves.add(new MajorMove(board, this, candidateDestinationCoordinate));
                }
            }
        }

        return Collections.unmodifiableList(LegalMoves);
    }

    @Override
    public String toString(){
        return PieceType.PAWN.toString();
    }
}
